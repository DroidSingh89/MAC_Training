package com.riz.admin.weatherapp.di.module;

import com.riz.admin.weatherapp.data.remote.RemoteDataSource;
import com.riz.admin.weatherapp.view.home.HomePresenter;

import dagger.Module;
import dagger.Provides;

/**
 * Created by singh on 12/7/17.
 */

@Module
public class HomeModule {


    @Provides
    HomePresenter providesHomePresenter(RemoteDataSource remoteDataSource){
        return new HomePresenter(remoteDataSource);
    }

}
