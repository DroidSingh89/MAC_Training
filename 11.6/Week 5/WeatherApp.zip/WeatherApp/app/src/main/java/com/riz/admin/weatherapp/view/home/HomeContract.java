package com.riz.admin.weatherapp.view.home;

import com.riz.admin.weatherapp.model.current.CurrentObservation;
import com.riz.admin.weatherapp.model.forecast.HourlyForecast;
import com.riz.admin.weatherapp.utils.BasePresenter;
import com.riz.admin.weatherapp.utils.BaseView;

import java.util.List;

/**
 * Created by singh on 12/7/17.
 */

public interface HomeContract {

    interface View extends BaseView{

        void updateCurrentWeather(CurrentObservation currentObservation);
        void updateForecastWeather(List<List<HourlyForecast>> hourlyForecast);

    }

    interface Presenter extends BasePresenter<View>{


        void getCurrentData(String zipcode);
        void getForecastData(String zipcode);



    }
}
