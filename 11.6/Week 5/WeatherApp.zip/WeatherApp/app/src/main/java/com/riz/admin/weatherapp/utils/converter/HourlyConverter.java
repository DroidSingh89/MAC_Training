package com.riz.admin.weatherapp.utils.converter;

import com.riz.admin.weatherapp.model.forecast.ForecastData;
import com.riz.admin.weatherapp.model.forecast.HourlyForecast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by singh on 12/7/17.
 */

public class HourlyConverter {

    List<List<HourlyForecast>> hourlyForecasts = new ArrayList<>();
    ForecastData forecastData;

    public HourlyConverter(ForecastData forecastData) {
        this.forecastData = forecastData;
    }

    public List<List<HourlyForecast>> convert(){



        List<HourlyForecast> hourlyForecastToday = forecastData.getHourlyForecast().subList(0,12);
        List<HourlyForecast> hourlyForecastTomorrow = forecastData.getHourlyForecast().subList(12,24);
        List<HourlyForecast> hourlyForecastDayAfter = forecastData.getHourlyForecast().subList(24,36);

        hourlyForecasts.add(hourlyForecastToday);
        hourlyForecasts.add(hourlyForecastTomorrow);
        hourlyForecasts.add(hourlyForecastDayAfter);

        return hourlyForecasts;

    }

}
