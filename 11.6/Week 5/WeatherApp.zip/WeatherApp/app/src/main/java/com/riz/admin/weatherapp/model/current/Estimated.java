
package com.riz.admin.weatherapp.model.current;


public class Estimated {


}
