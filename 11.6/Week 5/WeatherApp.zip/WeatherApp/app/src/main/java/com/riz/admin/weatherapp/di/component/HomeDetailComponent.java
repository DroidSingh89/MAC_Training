package com.riz.admin.weatherapp.di.component;

import com.riz.admin.weatherapp.di.module.HomeDetailModule;

import dagger.Subcomponent;

/**
 * Created by singh on 12/7/17.
 */

@Subcomponent(modules = HomeDetailModule.class)
public interface HomeDetailComponent {

    //void inject(HomeDetail homeDetail);
}
