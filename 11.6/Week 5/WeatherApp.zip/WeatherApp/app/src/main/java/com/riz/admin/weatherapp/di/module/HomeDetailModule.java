package com.riz.admin.weatherapp.di.module;

import com.riz.admin.weatherapp.data.remote.RemoteDataSource;
import com.riz.admin.weatherapp.view.homedetail.HomeDetailPresenter;

import dagger.Module;
import dagger.Provides;

/**
 * Created by singh on 12/7/17.
 */

@Module
public class HomeDetailModule {

    RemoteDataSource remoteDataSource;

    @Provides
    HomeDetailPresenter providesHomeDetailPresenter(){
        return new HomeDetailPresenter(remoteDataSource);
    }
}
