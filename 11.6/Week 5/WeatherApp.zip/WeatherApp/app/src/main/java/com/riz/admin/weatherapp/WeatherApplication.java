package com.riz.admin.weatherapp;

import android.app.Application;
import android.content.Context;

import com.riz.admin.weatherapp.di.component.AppComponent;
import com.riz.admin.weatherapp.di.component.DaggerAppComponent;
import com.riz.admin.weatherapp.di.component.HomeComponent;
import com.riz.admin.weatherapp.di.module.AppModule;
import com.riz.admin.weatherapp.di.module.HomeModule;

/**
 * Created by singh on 12/7/17.
 */

public class WeatherApplication extends Application {


    private static String BASE_URL = "http://api.wunderground.com/api/";
    private static String apiKey = "658671bf6a896877/";
    private AppComponent appComponent;
    private HomeComponent homeComponent;

    @Override
    public void onCreate() {
        super.onCreate();

        AppModule appModule = new AppModule(BASE_URL, apiKey);

        appComponent = DaggerAppComponent.builder()
                .appModule(appModule)
                .build();

    }

    public static WeatherApplication get(Context context) {
        return (WeatherApplication) context.getApplicationContext();
    }


    public HomeComponent getHomeComponent() {
        homeComponent = appComponent.add(new HomeModule());
        return homeComponent;
    }

    public void clearHomeComponent() {
        homeComponent = null;

    }


}
