package com.riz.admin.weatherapp.di.component;

import com.riz.admin.weatherapp.di.module.AppModule;
import com.riz.admin.weatherapp.di.module.HomeDetailModule;
import com.riz.admin.weatherapp.di.module.HomeModule;

import dagger.Component;

/**
 * Created by singh on 12/7/17.
 */

@Component(modules = AppModule.class)
public interface AppComponent {

    HomeComponent add(HomeModule homeModule);
    HomeDetailComponent add(HomeDetailModule homeDetailModule);

}
