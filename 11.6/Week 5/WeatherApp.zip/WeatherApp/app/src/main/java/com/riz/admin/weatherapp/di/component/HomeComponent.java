package com.riz.admin.weatherapp.di.component;

import com.riz.admin.weatherapp.di.module.HomeModule;
import com.riz.admin.weatherapp.view.home.Home;

import dagger.Subcomponent;

/**
 * Created by singh on 12/7/17.
 */

@Subcomponent(modules = HomeModule.class)
public interface HomeComponent {

    void inject(Home home);
}
