package com.riz.admin.weatherapp.view.homedetail;

import com.riz.admin.weatherapp.data.remote.RemoteDataSource;

import javax.inject.Inject;

/**
 * Created by singh on 12/7/17.
 */

public class HomeDetailPresenter {

    @Inject
    public HomeDetailPresenter(RemoteDataSource remoteDataSource) {


    }
}
