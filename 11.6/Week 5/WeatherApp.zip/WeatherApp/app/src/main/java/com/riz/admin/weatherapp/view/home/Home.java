package com.riz.admin.weatherapp.view.home;

import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.riz.admin.weatherapp.R;
import com.riz.admin.weatherapp.WeatherApplication;
import com.riz.admin.weatherapp.model.current.CurrentObservation;
import com.riz.admin.weatherapp.model.forecast.HourlyForecast;

import java.util.List;

import javax.inject.Inject;


public class Home extends AppCompatActivity implements HomeContract.View {

    private static final String TAG = "MainActivityTag";
    HomeListAdapter adapter;
    private RecyclerView recyclerView;
    private RecyclerView recyclerViewSec;
    private Toolbar myToolbar;
    private TextView tvMenuBarCity;
    private TextView tvMenuTemp;
    private TextView tvMenuCond;
    private EditText etZipCode;
    private Button btnsearchSip;


    @Inject
    HomePresenter presenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        WeatherApplication.get(this).getHomeComponent().inject(this);

        tvMenuBarCity = findViewById(R.id.tvMenuCityName);
        tvMenuTemp = findViewById(R.id.tvMenuTemp);
        tvMenuCond = findViewById(R.id.tvMenuCond);
        // toolbarMenuSetup();


        presenter.attachView(this);
        presenter.getCurrentData("30082");
        presenter.getForecastData("30082");
//        Log.d(TAG, "onCreate: "+ currentObservation.getImage().getTitle());



    }

//    private void toolbarMenuSetup() {
//        myToolbar = findViewById(R.id.main_app_toolbar);
//        etZipCode = findViewById(R.id.etSeachZipCode);
//        btnsearchSip = findViewById(R.id.btnSearchZip);
//        setSupportActionBar(myToolbar);
//
//        myToolbar.setTitle(R.string.app_name);
//
//        btnsearchSip.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View view) {
//                String zipCode = etZipCode.getText().toString();
//                Log.d("TAG", "onClick: " + zipCode);
//                getTempMainBar(zipCode);
//
//                getDailyTemp(zipCode);
//            }
//        });
//
//    }
//
//    private void getTempMainBar(String zipCode) {
//        RemoteDataSource.getCurrentWeather(zipCode + ".json").enqueue(new Callback<CurrentData>() {
//            @Override
//            public void onResponse(Call<CurrentData> call, Response<CurrentData> response) {
//                Log.d("Tag", "onResponse: " + response.body().getCurrentObservation().getDisplayLocation().getCity());
//
//                DisplayLocation getLocation = response.body().getCurrentObservation().getDisplayLocation();
//                String getWeather = response.body().getCurrentObservation().getWeather();
//                Double getTemp = response.body().getCurrentObservation().getTempF();
//                Integer geTempInt = getTemp.intValue();
//                tvMenuBarCity.setText(getLocation.getCity() + "," + getLocation.getState());
//                tvMenuTemp.setText(geTempInt.toString());
//                tvMenuCond.setText(getWeather);
//            }
//
//            @Override
//            public void onFailure(Call<CurrentData> call, Throwable t) {
//                Log.d("tag", "onFailure: " + t.getMessage());
//
//            }
//        });
//    }
//
//
//    private void getDailyTemp(String zipcode) {
//        // data to populate the RecyclerView with
//        final List<HourlyForecast> hourlyForecasts = new ArrayList<>();
//        final List<FCTTIME> fcttimes = new ArrayList<>();
//        final List<HourlyForecast> hourlyForecastsTomorw = new ArrayList<>();
//        final List<FCTTIME> fcttimesTomorw = new ArrayList<>();
//
//        final List<HourlyForecast> hourlyForecaststwo = new ArrayList<>();
//        // set up the RecyclerView
//        recyclerView = findViewById(R.id.rcToday);
//        recyclerViewSec = findViewById(R.id.rcTomorow);
//        int numberOfColumns = 4;
//        recyclerViewSec.setLayoutManager(new GridLayoutManager(this, numberOfColumns));
//        recyclerView.setLayoutManager(new GridLayoutManager(this, numberOfColumns));
//        RemoteDataSource.getForecastWeather(zipcode + ".json").enqueue(new Callback<ForecastData>() {
//            @Override
//            public void onResponse(Call<ForecastData> call, Response<ForecastData> response) {
//
//                hourlyForecasts.addAll(response.body().getHourlyForecast());
//
//                for (int i = 0; i < hourlyForecasts.size(); i++) {
//
//                    fcttimes.add(hourlyForecasts.get(i).getFCTTIME());
//
//
//                }
//                Calendar c = Calendar.getInstance();
//                SimpleDateFormat df = new SimpleDateFormat("d");
//                String todayDate = df.format(c.getTime());
//                int todaydateInt = Integer.parseInt(todayDate);
//                List<FCTTIME> fcttimestwo = new ArrayList<>();
//                for (int j = 0; j < fcttimes.size(); j++) {
//                    String todayString = fcttimes.get(j).getMday();
//                    int todayInt = Integer.parseInt(todayString);
//
//                    Log.d("Calender", "onResponse: " + todayInt);
//                    Log.d("FC", "onResponse: " + todaydateInt);
//                    if (todayInt <= todaydateInt) {
//                        Log.d("Ifstatement", "onResponse: ");
//                        fcttimestwo.add(fcttimes.get(j));
//                        hourlyForecaststwo.add(hourlyForecasts.get(j));
//
//                    } else {
//                        fcttimesTomorw.add(fcttimes.get(j));
//                        hourlyForecastsTomorw.add(hourlyForecasts.get(j));
//                    }
//                    Log.d("fcttimesTomorw", "onResponse: " + fcttimesTomorw.size());
//
//                }
//
//                Log.d("Two", "onResponse: " + fcttimestwo.size());
//
//                HomeListAdapter homeListAdapter = new HomeListAdapter(hourlyForecaststwo, fcttimestwo, Home.this);
//                recyclerView.setAdapter(homeListAdapter);
//                HomeListAdapter recycleViewAdapter = new HomeListAdapter(hourlyForecastsTomorw, fcttimesTomorw, Home.this);
//                recyclerViewSec.setAdapter(recycleViewAdapter);
//            }
//
//            @Override
//            public void onFailure(Call<ForecastData> call, Throwable t) {
//                Log.d("onFailure", "onFailure: " + t.getMessage());
//
//            }
//        });
//        adapter = new HomeListAdapter(hourlyForecasts, fcttimes, this);
//
//        recyclerView.setAdapter(adapter);
//    }


    @Override
    protected void onStart() {
        super.onStart();

    }

    @Override
    protected void onStop() {
        super.onStop();
        WeatherApplication.get(this).clearHomeComponent();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void showError(String s) {

    }

    @Override
    public void updateCurrentWeather(CurrentObservation currentObservation) {

        tvMenuBarCity.setText(currentObservation.getDisplayLocation().getCity()
                + ","
                + currentObservation.getDisplayLocation().getState());
                tvMenuTemp.setText(""+currentObservation.getTempF());
                tvMenuCond.setText(currentObservation.getWeather());
    }

    @Override
    public void updateForecastWeather(List<List<HourlyForecast>> hourlyForecast) {

        Log.d(TAG, "updateForecastWeather: Today" + hourlyForecast.get(0).get(0).getCondition());
        Log.d(TAG, "updateForecastWeather: Tomorrow" + hourlyForecast.get(1).get(0).getCondition());
        Log.d(TAG, "updateForecastWeather: DayAfter" + hourlyForecast.get(2).get(0).getCondition());


    }
}
