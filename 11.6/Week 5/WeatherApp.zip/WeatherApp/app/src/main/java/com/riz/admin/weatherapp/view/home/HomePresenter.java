package com.riz.admin.weatherapp.view.home;

import android.util.Log;

import com.riz.admin.weatherapp.data.remote.RemoteDataSource;
import com.riz.admin.weatherapp.model.current.CurrentData;
import com.riz.admin.weatherapp.model.current.CurrentObservation;
import com.riz.admin.weatherapp.model.forecast.ForecastData;
import com.riz.admin.weatherapp.model.forecast.HourlyForecast;
import com.riz.admin.weatherapp.utils.converter.HourlyConverter;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by singh on 12/7/17.
 */

public class HomePresenter implements HomeContract.Presenter {

    private static final String TAG = "HomePresenterTag";
    RemoteDataSource remoteDataSource;
    HomeContract.View view;
    List<List<HourlyForecast>> hourlyList = new ArrayList<>();

    @Inject
    public HomePresenter(RemoteDataSource remoteDataSource) {
        this.remoteDataSource = remoteDataSource;

    }


    @Override
    public void attachView(HomeContract.View view) {
        this.view = view;
    }

    @Override
    public void detachView() {
        this.view = null;
    }


    private CurrentObservation currentObservation = new CurrentObservation();

    @Override
    public void getCurrentData(String zipcode) {


        remoteDataSource.getCurrentWeatherRx(zipcode)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new Observer<CurrentData>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(CurrentData currentData) {

                        currentObservation = currentData.getCurrentObservation();

                    }

                    @Override
                    public void onError(Throwable e) {

                        Log.d(TAG, "onError: " + e.toString());
                    }

                    @Override
                    public void onComplete() {

                        view.updateCurrentWeather(currentObservation);

                    }
                });


    }

    @Override
    public void getForecastData(String zipcode) {

        remoteDataSource.getForecastWeatherRx(zipcode)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .map(new Function<ForecastData, List<List<HourlyForecast>>>() {
                    @Override
                    public List<List<HourlyForecast>> apply(ForecastData forecastData) throws Exception {


                        List<List<HourlyForecast>> hourlyForecasts;
                        HourlyConverter hourlyConverter = new HourlyConverter(forecastData);
                        hourlyForecasts = hourlyConverter.convert();
                        return hourlyForecasts;

                    }
                })
                .subscribe(new Observer<List<List<HourlyForecast>>>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                        Log.d(TAG, "onSubscribe: ");
                    }

                    @Override
                    public void onNext(List<List<HourlyForecast>> lists) {

                        hourlyList.addAll(lists);
                    }

                    @Override
                    public void onError(Throwable e) {

                    }

                    @Override
                    public void onComplete() {

                        view.updateForecastWeather(hourlyList);
                    }
                });

    }
}
